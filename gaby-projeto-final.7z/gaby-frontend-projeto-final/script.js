const formulario = document.querySelector("form");
const botao = document.querySelector("button");
const Inome = document.querySelector(".nome");
const Iemail = document.querySelector(".email");
const Isenha = document.querySelector(".senha");
const Itel = document.querySelector(".tel");
const statusSpan = document.getElementById("status");
const responseBodyPre = document.getElementById("responseBody");

function cadastrar() {
    fetch("http://localhost:8080/usuarios", {
        headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
        method: "POST",
        body: JSON.stringify({
            nome: Inome.value,
            email: Iemail.value,
            senha: Isenha.value,
            telefone: Itel.value
        })
    })
    .then(function(res) {
        statusSpan.textContent = res.status; // Exibe o status HTTP
        return res.json().then(body => {
            responseBodyPre.textContent = JSON.stringify(body, null, 2); // Exibe o corpo da resposta formatado
        }).catch(() => {
            responseBodyPre.textContent = "Resposta não é um JSON válido";
        });
    })
    .catch(function(error) {
        statusSpan.textContent = "Erro";
        responseBodyPre.textContent = error.toString(); // Exibe o erro
    });
}

function limpar() {
    Inome.value = "";
    Iemail.value = "";
    Isenha.value = "";
    Itel.value = "";
}

formulario.addEventListener("submit", function(event) {
    event.preventDefault();
    cadastrar();
    limpar();
});
